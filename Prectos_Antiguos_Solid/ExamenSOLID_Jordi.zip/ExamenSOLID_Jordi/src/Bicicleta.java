public interface Bicicleta {
    public String getID();
    public String getModelo();
    public String getTipo();

}
