public class Casco implements Extra{
    @Override
    public double tarifaHora() {
        return 0.0;
    }

    @Override
    public String getTipo() {
        return "";
    }
}
