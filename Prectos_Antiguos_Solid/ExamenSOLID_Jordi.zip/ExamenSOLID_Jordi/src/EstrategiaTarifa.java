public interface EstrategiaTarifa {
    public double calcularImporte();
    public String getTipo();
}
