public interface Extra {
    public double tarifaHora();
    public String getTipo();
}
