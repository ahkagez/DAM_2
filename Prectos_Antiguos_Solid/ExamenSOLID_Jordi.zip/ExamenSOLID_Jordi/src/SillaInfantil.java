public class SillaInfantil implements Extra{
    @Override
    public double tarifaHora() {
        return 0.05;
    }

    @Override
    public String getTipo() {
        return "";
    }
}
